<footer style="background-color: #EBECED; border-top: 2px solid #222; width:100vw;" class=" text-dark text-center text-lg-start">
    <div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
      &copy; 2021 All right reserved by Product Review
      
    </div>
    <!-- Copyright -->
  </footer>
