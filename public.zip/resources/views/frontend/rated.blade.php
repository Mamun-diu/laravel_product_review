@extends('frontend/master')

@section('content')
    <h1>Rated Page</h1>
@endsection
