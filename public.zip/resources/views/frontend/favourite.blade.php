@extends('frontend/master')

@section('content')
    <h1>Favourite Page</h1>
@endsection
