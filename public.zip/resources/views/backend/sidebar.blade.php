<ul id="sidebar" class="list-group">
    <li class="list-group-item"><a class="" href="#"><i class="fas fa-home me-2"></i>Dashboard</a></li>
    <li class="list-group-item"><a class="" href="#"><i class="fas fa-users me-2"></i>User</a></li>
    <li class="list-group-item"><a class="" href="{{ URL::to('/admin/add/product') }}"><i class="fas fa-cart-plus me-2"></i>Add Product</a></li>
    <li class="list-group-item"><a class="" href="{{ URL::to('/admin/product/show') }}"><i class="fas fa-eye me-2"></i>show Product</a></li>
    <li class="list-group-item"><a class="" href="{{ URL::to('admin/add/category') }}"><i class="fas fa-list-alt me-2"></i>Add Category</a></li>
    <li class="list-group-item"><a class="" href="{{ URL::to('/admin/show/category') }}"><i class="far fa-eye me-2"></i>Show Category</a></li>
    <li class="list-group-item"><a class="" href="{{ URL::to('/admin/add/price') }}"><i class="fas fa-dollar-sign me-2"></i>Add Price</a></li>
    <li class="list-group-item"><a class="" href="#"><i class="fas fa-search-dollar me-2"></i>Show Price</a></li>
    <li class="list-group-item"><a class="" href="#"><i class="fas fa-star me-2"></i>Rating</a></li>
    <li class="list-group-item"><a class="" href="#"><i class="fas fa-heart me-2"></i>Favourite</a></li>
</ul>
