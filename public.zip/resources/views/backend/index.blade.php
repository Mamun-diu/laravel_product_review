@extends('backend/master')
@section('content')
    <h1>Admin</h1>
@endsection
